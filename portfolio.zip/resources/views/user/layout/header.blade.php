<!doctype html>
<html class="no-js" lang="zxx">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Personal HTML-5 Template </title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="manifest" href="{{ asset('user/site.webmanifest') }}">
    <link rel="shortcut icon" type="image/x-icon" href="{{ asset('user/assets/img/favicon.ico') }}">

    <!-- CSS here -->
    <link rel="stylesheet" href="{{ asset('user/assets/css/bootstrap.min.css') }}">
    <link rel="stylesheet" href="{{ asset('user/assets/css/owl.carousel.min.css') }}">
    <link rel="stylesheet" href="{{ asset('user/assets/css/slicknav.css') }}">
    <link rel="stylesheet" href="{{ asset('user/assets/css/flaticon.css') }}">
    <link rel="stylesheet" href="{{ asset('user/assets/css/animate.min.css') }}">
    <link rel="stylesheet" href="{{ asset('user/assets/css/magnific-popup.css') }}">
    <link rel="stylesheet" href="{{ asset('user/assets/css/fontawesome-all.min.css') }}">
    <link rel="stylesheet" href="{{ asset('user/assets/css/themify-icons.css') }}">
    <link rel="stylesheet" href="{{ asset('user/assets/css/slick.css') }}">
    <link rel="stylesheet" href="{{ asset('user/assets/css/nice-select.css') }}">
    <link rel="stylesheet" href="{{ asset('user/assets/css/style.css') }}">
</head>

<body>

<header>
    <div class="header-area">
        <div class="main-header header-sticky">
            <div class="container-fluid">
                <div class="row align-items-center">

                    <!-- Logo -->
                    <div class="col-xl-2 col-lg-2 col-md-1">
                        <div class="logo">
                            <a href="{{ url('/') }}">
                                <img src="{{ asset('user/assets/img/logo/logo.png') }}" alt="">
                            </a>
                        </div>
                    </div>

                    <div class="col-xl-10 col-lg-10 col-md-10">
                        <div class="menu-main d-flex align-items-center justify-content-end">

                            <!-- Main-menu -->
                            <div class="main-menu f-right d-none d-lg-block">
                                <nav>
                                    <ul id="navigation">
                                        <li><a href="{{ url('/') }}">Home</a></li>
                                        <li><a href="{{ asset('user/about.html') }}">About</a></li>
                                        <li><a href="{{ asset('user/services.html') }}">Services</a></li>
                                        <li><a href="{{ asset('user/portfolio.html') }}">Portfolio</a></li>
                                        <li>
                                            <a href="#">Page</a>
                                            <ul class="submenu">
                                                <li><a href="{{ asset('user/blog.html') }}">Blog</a></li>
                                                <li><a href="{{ asset('user/blog_details.html') }}">Blog Details</a></li>
                                                <li><a href="{{ asset('user/elements.html') }}">Element</a></li>
                                                <li><a href="{{ asset('user/portfolio_details.html') }}">Portfolio Details</a></li>
                                            </ul>
                                        </li>
                                        <li><a href="{{ asset('user/contact.html') }}">Contact</a></li>
                                    </ul>
                                </nav>
                            </div>

                            <div class="header-right-btn f-right d-none d-xl-block ml-20">
                                <a href="#" class="btn header-btn">Get Free Consultent</a>
                            </div>

                        </div>
                    </div>

                    <!-- Mobile Menu -->
                    <div class="col-12">
                        <div class="mobile_menu d-block d-lg-none"></div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</header>
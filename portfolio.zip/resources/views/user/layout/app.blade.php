@include('user.layout.header')
@section('content')

@show
@include('user.layout.footer')
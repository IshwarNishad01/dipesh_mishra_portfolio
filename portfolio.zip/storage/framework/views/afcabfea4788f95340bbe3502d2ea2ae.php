<?php echo $__env->make('user.layout.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->startSection('content'); ?>

<?php echo $__env->yieldSection(); ?>
<?php echo $__env->make('user.layout.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\laravel12\portfolio\resources\views/user/layout/app.blade.php ENDPATH**/ ?>
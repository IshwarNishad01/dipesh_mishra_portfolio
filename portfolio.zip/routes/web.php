<?php

use App\Http\Controllers\User\UserIndexController;
use Illuminate\Support\Facades\Route;

Route::controller(UserIndexController::class)->name('user.')->group(function(){
    Route::get('/','index');
});
